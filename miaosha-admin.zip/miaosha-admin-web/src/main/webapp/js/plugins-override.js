~function(){
	
	if($.fn.twbsPagination){
		$.extend($.fn.twbsPagination.defaults, {
			first : "首页",
			prev : "上一页",
			next : "下一页",
			last : "最后一页"
		});
	}
		
}();
